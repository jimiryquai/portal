import * as React from "react";
import parse from 'html-react-parser';

export interface HtmlPreviewState {
  htmlData: string;
}

export interface HtmlPreviewProps extends HtmlPreviewState {
}

class HtmlPreview extends React.Component<HtmlPreviewProps> {
  constructor(props: HtmlPreviewProps) {
    super(props);
    this.state = {
      htmlData: props.htmlData
    }
  }

  render() {
    return (
      <div>
        {parse(this.props.htmlData)}
      </div>
      );
    }
}

export { HtmlPreview };

export default HtmlPreview;
