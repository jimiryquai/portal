import * as React from "react";
import HtmlPreview from "./htmlPreview";

export interface HtmlEditorPanelState {
  htmlData: string;
  //jobTitle: string;
  //tokenName: string;
}

export interface HtmlEditorPanelProps extends HtmlEditorPanelState {
  //onChangeHandler: (value: string, tokenName: string) => void;
}

class HtmlEditorPanel extends React.Component<HtmlEditorPanelProps> {
  constructor(props: HtmlEditorPanelProps) {
    super(props);
    this.state = {
      htmlData: props.htmlData,
      //tokenName:props.tokenName
    }
  }

  render() {
    return (
    <div>
      <HtmlPreview 
        htmlData={this.props.htmlData}
      ></HtmlPreview>
    </div>
      );
    }
}

export { HtmlEditorPanel };

export default HtmlEditorPanel;
