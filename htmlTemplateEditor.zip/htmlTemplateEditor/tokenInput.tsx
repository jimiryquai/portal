
import * as React from "react";

export interface TokenInputState {
  inputValue: string;
  tokenName: string;
}

export interface TokenInputProps extends TokenInputState {
  onChangeHandler2: (value: string, tokenName: string) => void;
}

class TokenInput extends React.Component<TokenInputProps, TokenInputState> {
  constructor(props: TokenInputProps) {
    super(props);
    this.state = {
      inputValue: props.inputValue,
      tokenName: props.tokenName
    }
    this.handleChange = this.handleChange.bind(this);
  }
/*
  const [submitText, setSubmitText] = useState('');

	function handleEditAvatarClick() {
		setSubmitText(submitSave);
		setIsEditAvatarPopupOpen(true);
		window.addEventListener('keyup', handleEscClose);
	}
*/

  handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    this.props.onChangeHandler2(e.target.value, this.props.tokenName);
  }
  
  render() {
    return (
      <div>
          <input
            onChange={this.handleChange}
            value={this.props.inputValue}
          ></input>
      </div>
      );
    }
}

export { TokenInput };

export default TokenInput;
