import { title } from "process";
import React = require("react");
import ReactDOM = require("react-dom");
import {IInputs, IOutputs} from "./generated/ManifestTypes";
import { HtmlEditorPanel, HtmlEditorPanelProps } from "./htmlEditorPanel";

export class htmlTemplateEditor implements ComponentFramework.StandardControl<IInputs, IOutputs> {

	private _container: HTMLDivElement;
	private _context: ComponentFramework.Context<IInputs>;
	private _notifyOutputChanged: () => void;
	private _htmlData: string;
	private _tokenTemplate: string;
	private _token1: string;
	private _token2: string;
	private _token3: string;
	private _token4: string;
	private _token5: string;
	private _token6: string;
	private _token7: string;
	private _token8: string;
	private _token9: string;
	private _token10: string;

	/**
	 * Empty constructor.
	 */
	constructor()
	{

	}

	/**
	 * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
	 * Data-set values are not initialized here, use updateView.
	 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
	 * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
	 * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
	 * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
	 */
	public init(
		context: ComponentFramework.Context<IInputs>, 
		notifyOutputChanged: () => void, 
		state: ComponentFramework.Dictionary, 
		container:HTMLDivElement)
	{
			this._context = context;
			this._container = container;
			this._notifyOutputChanged = notifyOutputChanged;
			this._container.innerHTML = "";
			this._htmlData = context.parameters.htmlData.raw!;
			this._tokenTemplate = context.parameters.tokenTemplate.raw!;
			this._token1 = context.parameters.token1.raw!;
			this._token2 = context.parameters.token2.raw!;
			this._token3 = context.parameters.token3.raw!;
			this._token4 = context.parameters.token4.raw!;
			this._token5 = context.parameters.token5.raw!;
			this._token6 = context.parameters.token6.raw!;
			this._token7 = context.parameters.token7.raw!;
			this._token8 = context.parameters.token8.raw!;
			this._token9 = context.parameters.token9.raw!;
			this._token10 = context.parameters.token10.raw!;
	}


	/**
	 * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
	 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
	 */
	public updateView(context: ComponentFramework.Context<IInputs>): void
	{
		debugger;
		this._htmlData = context.parameters.htmlData.raw!;
		this._tokenTemplate = context.parameters.tokenTemplate.raw!;
		this._token1 = context.parameters.token1.raw!;
		this._token2 = context.parameters.token2.raw!;
		this._token3 = context.parameters.token3.raw!;
		this._token4 = context.parameters.token4.raw!;
		this._token5 = context.parameters.token5.raw!;
		this._token6 = context.parameters.token6.raw!;
		this._token7 = context.parameters.token7.raw!;
		this._token8 = context.parameters.token8.raw!;
		this._token9 = context.parameters.token9.raw!;
		this._token10 = context.parameters.token10.raw!;

		this.updatedContent();
	}

	public renderPage() {

		let htmlEditorPanelProps: HtmlEditorPanelProps = {
			htmlData: this._htmlData,
			//tokenName: "<**SL_TOKEN**>",
			//onChangeHandler: this.updatedContent.bind(this)
		}

		ReactDOM.render(React.createElement(HtmlEditorPanel, htmlEditorPanelProps), this._container);
	}

	/** 
	 * It is called by the framework prior to a control receiving new data. 
	 * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
	 */
	public getOutputs(): IOutputs
	{
		debugger;
		return {
			htmlData: this._htmlData
		};
	}

	/** 
	 * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
	 * i.e. cancelling any pending remote calls, removing listeners, etc.
	 */
	public destroy(): void
	{
		// Add code to cleanup control if necessary
	}

	public updatedContent() {
		debugger;
		let tempHtml = this._tokenTemplate;
		tempHtml = tempHtml.replace('<**TOKEN1**>', this.ProcessListItem(this._token1));
		tempHtml = tempHtml.replace('<**TOKEN2**>', this.ProcessListItem(this._token2));
		tempHtml = tempHtml.replace('<**TOKEN3**>', this.ProcessListItem(this._token3));
		tempHtml = tempHtml.replace('<**TOKEN4**>', this.ProcessListItem(this._token4));
		tempHtml = tempHtml.replace('<**TOKEN5**>', this.ProcessListItem(this._token5));
		tempHtml = tempHtml.replace('<**TOKEN6**>', this.ProcessListItem(this._token6));
		tempHtml = tempHtml.replace('<**TOKEN7**>', this.ProcessListItem(this._token7));
		tempHtml = tempHtml.replace('<**TOKEN8**>', this.ProcessListItem(this._token8));
		tempHtml = tempHtml.replace('<**TOKEN9**>', this.ProcessListItem(this._token9));
		tempHtml = tempHtml.replace('<**TOKEN10**>', this.ProcessListItem(this._token10));

		if(this._htmlData !== tempHtml){
			this._htmlData = tempHtml;
			this._notifyOutputChanged();
		}
		this.renderPage();
	}

	public ProcessListItem(rawText: string): string{
		debugger;
		if(rawText === null) {
			return "";
		}
		let htmlText = "";
		let splitText = rawText.split('\n');
		if(splitText.length > 1)
		{
			splitText.map((listItem, index) => htmlText += `<li>${listItem}</li>`);
		}else {
			htmlText = rawText;
		}

		return htmlText;
	}
}