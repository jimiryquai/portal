# HTML Editor

## Enable To

Bind to datasett

- field

## Setup

Use the solution.zip to install managed component to your environment

## Solution creation

navigate to htmlTemplatedEditor folder
create folder called htmlTemplatedEditorSolution
pac solution init --publisher-name XXX --publisher-prefix YYY

pac solution add-reference --path ../

msbuild /t:build /restore

## Solution install

Manually download zip file from releases and import.

## Solution Deployment

To deploy to your environment using the command line
copy the repository locally
connect to remote env
pac auth create --url XXX
enter credentials
command to push to env
pac pcf push --publisher-prefix YYY
