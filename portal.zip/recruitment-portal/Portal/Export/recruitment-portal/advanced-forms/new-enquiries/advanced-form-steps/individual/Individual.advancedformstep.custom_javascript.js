if (window.jQuery) {
	(function ($) {
		$(document).ready(function () {
			var requiresSleepInControl = $('#pfc_doesindividualrequiresleepinsupport');
			var sharedSleepInControl = $('#pfc_ifyescouldthissleepinbeshared');

			var showControl = control => control.closest('tr').show();
			var hideControl = control => control.closest('tr').hide();

			if (requiresSleepInControl.prop('checked')) {
				showControl(sharedSleepInControl);
			} else {
				hideControl(sharedSleepInControl);
				sharedSleepInControl.prop('checked', false);
			}

			requiresSleepInControl.on('click', function () {
				if ($(this).prop('checked')) {
					showControl(sharedSleepInControl);
				} else {
					hideControl(sharedSleepInControl);
					sharedSleepInControl.prop('checked', false);
				}
			});
		});
	})(window.jQuery);
}
