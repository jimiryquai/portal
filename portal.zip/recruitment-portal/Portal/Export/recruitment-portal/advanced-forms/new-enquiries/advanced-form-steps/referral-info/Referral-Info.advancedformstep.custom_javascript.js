if (window.jQuery) {
	(function ($) {
		$(document).ready(function () {
			var requiresSleepInControl = $('#pfc_doesindividualrequiresleepinsupport');
			var sharedSleepInControl = $('#pfc_ifyescouldthissleepinbeshared');
			var supportChangeControl = $('#pfc_willcurrentsupporthourschange');
			var includeSleepInControl = $('#pfc_wouldthissupportincludesleepinsupport');
			var hoursNeededControl = $('#pfc_numberofhoursneeded');
			var hoursNeededLabelText = $('#pfc_numberofhoursneeded_label').text();
			var hoursNeededSelector = 'pfc_numberofhoursneeded';
			var tieredRateControl = $('#pfc_tieredrate');
			var currentSupportControl = $('#pfc_currentweeklysupporthours');
			var allPanelsSelector = $('div[id^="collapseListGroup"]');
			var reasonControl = $('#pfc_reasonforserviceneed');
			var reasonOtherControl = $('#pfc_reasonforserviceneedother');
			var reasonOtherSelector = 'pfc_reasonforserviceneedother';
			var reasonOtherLabelText = $('#pfc_reasonforserviceneedother_label').text();
			var accommodationControl = $('#pfc_accommodationneeds');
			var accommodationOtherControl = $('#pfc_accommodationneedsother');
			var accommodationOtherSelector = 'pfc_accommodationneedsother';
			var accommodationOtherLabelText = $('#pfc_accommodationneedsother_label').text();
			var typeControl = $('#pfc_typeofserviceneeded');
			var typeOtherControl = $('#pfc_typeofserviceneededother');
			var typeOtherSelector = 'pfc_typeofserviceneededother';
			var typeOtherLabelText = $('#pfc_typeofserviceneededother_label').text();

			var hidePanels = (panels) => panels.collapse('hide');
			var showControl = (control) => control.closest('tr').show();
			var hideControl = (control) => control.closest('tr').hide();

			function calculateIndicativeCosting() {
				var tieredRateValue = $('#pfc_tieredrate').val();
				var hoursNeededValue = $('#pfc_numberofhoursneeded').val();
				var indicativeCostingControl = $('#pfc_indicativecosting');
				var currentSupportValue = $('#pfc_currentweeklysupporthours').val();
				var hourlyRate;

				if (tieredRateValue == '') {
					indicativeCostingControl.val('');
				} else {
					switch (tieredRateValue) {
						case '229330000':
							hourlyRate = 20.59;
							break;
						case '229330001':
							hourlyRate = 22.19;
							break;
						case '229330002':
							hourlyRate = 23.35;
							break;
						case '229330003':
							hourlyRate = 24.48;
							break;
						default:
							hourlyRate = 0.0;
					}

					if (hoursNeededValue != '' && $.isNumeric(hoursNeededValue)) {
						indicativeCostingControl.val(hoursNeededValue * hourlyRate);
					} else if (currentSupportValue != '' && $.isNumeric(currentSupportValue) && hoursNeededValue == '') {
						indicativeCostingControl.val(currentSupportValue * hourlyRate);
					} else {
						indicativeCostingControl.val('');
					}
				}
			}

			function showPanel() {
				var tieredRateValue = $('#pfc_tieredrate').val();
				var id;
				switch (tieredRateValue) {
					case '229330000':
						id = '#collapseListGroup1';
						break;
					case '229330001':
						id = '#collapseListGroup2';
						break;
					case '229330002':
						id = '#collapseListGroup3';
						break;
					case '229330003':
						id = '#collapseListGroup4';
						break;
				}

				id ? $(id).collapse('show') : false;
			}

			function addRequiredFieldValidator(control, label) {
				if (typeof Page_Validators == 'undefined') return;
				$(`#${control}_label`).parent().addClass('required');
				var validator = document.createElement('span');
				validator.style.display = 'none';
				validator.id = `RequiredFieldValidator${control}`;
				validator.controltovalidate = `${control}`;
				validator.errormessage = "<a href='#" + control + "_label'>" + label + ' is a mandatory field.</a>';
				validator.display = 'Dynamic';
				validator.validationGroup = ''; // Set this if you have set ValidationGroup on the form
				validator.initialvalue = '';
				validator.evaluationfunction = function () {
					var value = $(`#${control}`).val();
					if (value == null || value == '') {
						return false;
					} else {
						return true;
					}
				};
				// Add the new validator to the page validators array:
				Page_Validators.push(validator);

				// Wire-up the click event handler of the validation summary link
				$(`a[href='#${control}_label']`).on('click', function () {
					scrollToAndFocus(`${control}_label`, `${control}`);
				});
			}

			function removeRequiredFieldValidator(control) {
				$.each(Page_Validators, function (index, validator) {
					if (validator.id == `RequiredFieldValidator${control}`) {
						Page_Validators.splice(index, 1);
						return false;
					}
				});
				$(`#${control}_label`).parent().removeClass('required');
			}

			currentSupportControl.on('change', calculateIndicativeCosting);

			tieredRateControl.on('change', calculateIndicativeCosting);

			tieredRateControl.on('change', function () {
				hidePanels(allPanelsSelector);
				showPanel();
			});

			hoursNeededControl.on('change', calculateIndicativeCosting);

			hidePanels(allPanelsSelector);

			if (requiresSleepInControl.prop('checked')) {
				showControl(sharedSleepInControl);
			} else {
				hideControl(sharedSleepInControl);
				sharedSleepInControl.prop('checked', false);
			}

			if (supportChangeControl.prop('checked')) {
				showControl(includeSleepInControl);
				showControl(hoursNeededControl);
				addRequiredFieldValidator(hoursNeededSelector, hoursNeededLabelText);
			} else {
				hideControl(includeSleepInControl);
				includeSleepInControl.prop('checked', false);
				hideControl(hoursNeededControl);
				removeRequiredFieldValidator(hoursNeededSelector);
				hoursNeededControl.val('');
			}

			// On page load check if value of Reason For Referral optionset is 'Other'
			if (reasonControl.val() === '229330007') {
				showControl(reasonOtherControl);
				addRequiredFieldValidator(reasonOtherSelector, reasonOtherLabelText);
			} else {
				hideControl(reasonOtherControl);
				removeRequiredFieldValidator(reasonOtherSelector);
				reasonOtherControl.val('');
			}

			// On page load check if value of Accommodation Needs optionset is 'Other'
			if (accommodationControl.val() === '229330007') {
				showControl(accommodationOtherControl);
				addRequiredFieldValidator(accommodationOtherSelector, accommodationOtherLabelText);
			} else {
				hideControl(accommodationOtherControl);
				removeRequiredFieldValidator(accommodationOtherSelector);
				accommodationOtherControl.val('');
			}

			// On page load check if value of Type of Service Needed optionset is 'Other'
			if (typeControl.val() === '229330008') {
				showControl(typeOtherControl);
				addRequiredFieldValidator(typeOtherSelector, typeOtherLabelText);
			} else {
				hideControl(typeOtherControl);
				removeRequiredFieldValidator(typeOtherSelector);
				typeOtherControl.val('');
			}

			typeControl.on('change', function () {
				if ($(this).val() === '229330008') {
					showControl(typeOtherControl);
					addRequiredFieldValidator(typeOtherSelector, typeOtherLabelText);
				} else {
					hideControl(typeOtherControl);
					removeRequiredFieldValidator(typeOtherSelector);
					typeOtherControl.val('');
				}
			});

			accommodationControl.on('change', function () {
				if ($(this).val() === '229330007') {
					showControl(accommodationOtherControl);
					addRequiredFieldValidator(accommodationOtherSelector, accommodationOtherLabelText);
				} else {
					hideControl(accommodationOtherControl);
					removeRequiredFieldValidator(accommodationOtherSelector);
					accommodationOtherControl.val('');
				}
			});

			reasonControl.on('change', function () {
				if ($(this).val() === '229330007') {
					showControl(reasonOtherControl);
					addRequiredFieldValidator(reasonOtherSelector, reasonOtherLabelText);
				} else {
					hideControl(reasonOtherControl);
					removeRequiredFieldValidator(reasonOtherSelector);
					reasonOtherControl.val('');
				}
			});

			supportChangeControl.on('click', function () {
				if ($(this).prop('checked')) {
					showControl(includeSleepInControl);
					showControl(hoursNeededControl);
					addRequiredFieldValidator(hoursNeededSelector, hoursNeededLabelText);
				} else {
					hideControl(includeSleepInControl);
					includeSleepInControl.prop('checked', false);
					hideControl(hoursNeededControl);
					removeRequiredFieldValidator(hoursNeededSelector);
					hoursNeededControl.val('');
					calculateIndicativeCosting();
				}
			});
		});
	})(window.jQuery);
}
