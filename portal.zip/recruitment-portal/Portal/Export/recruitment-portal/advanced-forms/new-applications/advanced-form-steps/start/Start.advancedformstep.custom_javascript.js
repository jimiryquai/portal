$(document).ready(function ()
{
	var nextButton = $('#NextButton');
	var wholeConsentYes = $('#pfc_wholerecruitmentprocessconsent_1');
	var wholeConsentNo = $('#pfc_wholerecruitmentprocessconsent_0');
	var referencesConsentYes = $('#pfc_referencesconsent_1');
	var referencesConsentNo = $('#pfc_referencesconsent_0');
	var thirdPartyConsentYes = $('#pfc_thirdpartyconsent_1');
	var thirdPartyConsentNo = $('#pfc_thirdpartyconsent_0');
	var dataRetentionConsentYes = $('#pfc_dataretentionconsent_1');
	var dataRetentionConsentNo = $('#pfc_dataretentionconsent_0');
	var dataStorageConsentYes = $('#pfc_employeedatastorageconsent_1');
	var dataStorageConsentNo = $('#pfc_employeedatastorageconsent_0');
	var yesArray = [
        wholeConsentYes,
        referencesConsentYes,
        thirdPartyConsentYes,
        dataRetentionConsentYes,
        dataStorageConsentYes,
    ];
	var noArray = [wholeConsentNo, referencesConsentNo, thirdPartyConsentNo, dataRetentionConsentNo, dataStorageConsentNo];
	nextButton.prop('disabled', true);

	function hasConsent(consentYes, consentNo)
	{
		!consentYes.prop('checked');
		!consentNo.prop('checked');
	}

	function checkScore()
	{
		var score = 0;
		$.each(yesArray, function (i)
		{
			if ($(this).is(':checked'))
			{
				score += 1;
			}
			else
			{
				if (score > 0)
				{
					score -= 1;
				}
			}
		});
		return score;
	}

	function isButtonDisabled(score)
	{
		if (score === 5)
		{
			nextButton.prop('disabled', false);
		}
		else
		{
			nextButton.prop('disabled', true);
		}
	}
	$.each(yesArray, function (i)
	{
		$(this).click(function ()
		{
			hasConsent(yesArray[i], noArray[i]);
			var score = checkScore();
			isButtonDisabled(score);
		});
	});
	$.each(noArray, function (i)
	{
		$(this).click(function ()
		{
			hasConsent(yesArray[i], noArray[i]);
			var score = checkScore();
			isButtonDisabled(score);
		});
	});
});