if (window.jQuery) {
	(function ($) {
		function error() {
			$('.validation-summary').attr('style', 'display: block');
            $('.validation-summary').removeClass('success alert-success');
            $('.validation-summary').addClass('alert alert-error alert-danger');
		};

        $(function(){

            var list = $('.entity-grid.subgrid');
            var submitButton = $('#UpdateButton')[0];
            list.on('loaded', function () {

                var refereeTypes = list.find("td[data-th='Referee Type']");
                var arr = jQuery.makeArray(refereeTypes);
                var currentEmployerCount = 0;

                $.each(arr, function( i, v ) {
                    if (($(this).text().match('Current/Most Recent Employer'))) {
                        currentEmployerCount += 1;
					}
                });

                var button =  $('.create-action')[0];
                var rowCount = $('#referees_subgrid table tbody tr').length;
                if (rowCount == 2 && currentEmployerCount == 1) {
                    $(button).attr({
                        style: 'pointer-events: none; cursor: not-allowed;',
                        disabled: 'disabled'
                    });
                    $('.validation-summary').attr('style', 'display: block');
                    $('.validation-summary').removeClass('alert-error alert-danger alert-block alert-warning');
                    $('.validation-summary').addClass('alert success alert-success');
                    $('div.validation-summary').text(`Thank you {{ user.firstname }}. You have provided ${rowCount} valid referee(s). Please go ahead and hit the Submit button so that we can proceed with your application`);
                    $(submitButton).prop('disabled', false);
                } else if (rowCount == 2 && currentEmployerCount == 2){
					error();
                    $(button).attr({
                        style: 'pointer-events: none; cursor: not-allowed;',
                        disabled: 'disabled'
                    });
                    $('div.validation-summary').text(
							`Thank you {{ user.firstname }}. You have provided ${rowCount} referee(s). However, they are both of Referee Type: Current/Most Recent Employer. Please edit your entries so that you only have one referee of Referee Type: Current/Most Recent Employer to proceed.`
						);
                    $(submitButton).prop('disabled', true);
                } else if (rowCount == 2 && currentEmployerCount == 0){
					error();
                    $('div.validation-summary').text(
							`Thank you {{ user.firstname }}. You have provided ${rowCount} referee(s). However, one of your referees must be of Referee Type: Current/Most Recent Employer. Please add a referee of Referee Type: Current/Most Recent Employer to proceed.`
						);
                    $(submitButton).prop('disabled', true);
                } else if (rowCount == 1 && currentEmployerCount == 1) {
                    error();
                    $('div.validation-summary').text(`Thank you {{ user.firstname }}. You have provided ${rowCount} valid referee. Please go ahead and provide another referee that is not of Referee Type: Current/Most Recent Employer to proceed`);
                    $(button).removeAttr('disabled').removeAttr('style');
                    $(submitButton).prop('disabled', true);
                } else if (rowCount == 1 && currentEmployerCount == 1) {
                    error();
                    $('div.validation-summary').text(`Thank you {{ user.firstname }}. You have provided ${rowCount} referee. Please provide another referee which must be of Referee Type: Current/Most Recent Employer to proceed`);
                     $(button).removeAttr('disabled').removeAttr('style');
                    $(submitButton).prop('disabled', true);
            	} else {
                    $('.validation-summary').attr('style', 'display: block');
                    $('.validation-summary').removeClass('alert-error alert-danger success alert-success');
                    $('.validation-summary').addClass('alert alert-block alert-warning');
                    $('div.validation-summary').text(`Hi {{ user.firstname }}. Please provide 2 referees - 1 of which must be your Current/Most Recent Employer.`);
                     $(button).removeAttr('disabled').removeAttr('style');
                    $(submitButton).prop('disabled', true);
                }
          	});
		});

		if (typeof entityFormClientValidate != 'undefined') {
			var originalValidationFunction = entityFormClientValidate;
			if (originalValidationFunction && typeof originalValidationFunction == 'function') {
				entityFormClientValidate = function () {
					originalValidationFunction.apply(this, arguments);
					if ($(submitButton).prop('disabled', true)) {
						return false;
					} else {
						return true;
					}
				};
			}
		}
	})(window.jQuery);
}