if (window.jQuery) {
	(function ($) {
		function error() {
			$('.validation-summary').attr('style', 'display: block');
			$('.validation-summary').removeClass('success alert-success');
			$('.validation-summary').addClass('alert alert-error alert-danger');
		}

		$(function () {
			var list = $('.entity-grid.subgrid');
			var submitButton = $('#UpdateButton')[0];
			list.on('loaded', function () {
				var addButton = $('.create-action')[0];
				var rowCount = $('#employment_subgrid table tbody tr').length;
				console.log('Row Count:', rowCount);
				if (rowCount == 0 ) {
                    	$(submitButton).prop('disabled', true);
                }
			});
		});

		if (typeof entityFormClientValidate != 'undefined') {
			var originalValidationFunction = entityFormClientValidate;
			if (originalValidationFunction && typeof originalValidationFunction == 'function') {
				entityFormClientValidate = function () {
					originalValidationFunction.apply(this, arguments);
					if ($(submitButton).prop('disabled', true)) {
						return false;
					} else {
						return true;
					}
				};
			}
		}
	})(window.jQuery);
}
