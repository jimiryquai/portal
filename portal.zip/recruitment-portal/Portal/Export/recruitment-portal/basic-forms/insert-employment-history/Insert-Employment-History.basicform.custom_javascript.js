if (window.jQuery) {
	(function ($) {
		$(document).ready(function () {
			var leavingReasonSelector = 'pfc_reasonforleaving';
			var jobTitleSelector = 'pfc_jobtitle';
            var gapReasonSelector = 'pfc_reasonforgap';
			var endDateSelector = 'pfc_enddate';
			var isGapNo = $('#pfc_isgapinemployment_0');
			var isGapYes = $('#pfc_isgapinemployment_1');
			var isCurrentEmployer = $('#pfc_iscurrentemployment');
			var gapReason = $('#pfc_reasonforgap');
			var employerName = $('#pfc_employername');
			var jobTitle = $('#pfc_jobtitle');
			var startDate = $('#pfc_startdate');
			var endDate = $('#pfc_enddate');
			var jobTitleLabelText = $('#pfc_jobtitle_label').text();
			var leavingReason = $('#pfc_reasonforleaving');
			var leavingReasonLabelText = $('#pfc_reasonforleaving_label').text();
            var gapReasonLabelText = $('#pfc_reasonforgap_label').text();
			var endDateLabelText = $('#pfc_iscurrentemployment_label').text();
            // Form load settings
			toggleHidden(gapReason);
			addRequiredFieldValidator(endDateSelector, endDateLabelText);
            addRequiredFieldValidator(leavingReasonSelector, leavingReasonLabelText);
            addRequiredFieldValidator(jobTitleSelector, jobTitleLabelText);
			isGapNo.prop('value', 1);
			isGapYes.prop('value', 0);
			startDate.next().data('DateTimePicker').maxDate(moment()); // force the past
            //

			function handleChecked(Yes, No) {
				!Yes.prop('checked');
				!No.prop('checked');
			}

			function toggleHidden(control) {
				if (control.closest('tr').is(':visible')) {
					control.closest('tr').hide();
				} else {
					control.closest('tr').show();
				}
			}

			function addRequiredFieldValidator(control, label) {
			 if (typeof Page_Validators == 'undefined') return;
				$(`#${control}_label`).parent().addClass('required');
				var validator = document.createElement('span');
				validator.style.display = 'none';
				validator.id = `RequiredFieldValidator${control}`;
				validator.controltovalidate = `${control}`;
				validator.errormessage = "<a href='#" + control + "_label'>" + label + ' is a mandatory field.</a>';
                validator.display = 'Dynamic';
				validator.validationGroup = ''; // Set this if you have set ValidationGroup on the form
				validator.initialvalue = '';
                validator.evaluationfunction = function () {
					var value = $(`#${control}`).val();
					if (value == null || value == '') {
						return false;
					} else {
						return true;
					}
              	};
                // Add the new validator to the page validators array:
                Page_Validators.push(validator);

                // Wire-up the click event handler of the validation summary link:
               $(`a[href='#${control}_label']`).on('click', function () {
				scrollToAndFocus(`${control}_label`, `${control}`);
				});
			};

			function removeRequiredFieldValidator(control) {
				$.each(Page_Validators, function (index, validator) {
					if (validator.id == `RequiredFieldValidator${control}`) {
						Page_Validators.splice(index, 1);
						return false;
					}
				});
				$(`#${control}_label`).parent().removeClass('required');
			}

			isGapYes.on('click', function () {
				handleChecked(isGapYes, isGapNo);
				if ($(this).prop('value') == 0) {
					$.each([gapReason, jobTitle, leavingReason, employerName, isCurrentEmployer], function (index, value) {
						toggleHidden(value);
					});
					employerName.val('Gap');
					jobTitle.val('N/A');
					leavingReason.val('N/A');
                    addRequiredFieldValidator(gapReasonSelector, gapReasonLabelText);
					removeRequiredFieldValidator(leavingReasonSelector);
                    removeRequiredFieldValidator(jobTitleSelector);
					$(this).prop('value', 1);
					isGapNo.prop('value', 0);
				} else if ($(this).prop('value') == 1) {
					return;
				}
			});

			isGapNo.on('click', function () {
				handleChecked(isGapYes, isGapNo);
				if ($(this).prop('value') == 0) {
					$.each([gapReason, jobTitle, leavingReason, employerName, isCurrentEmployer], function (index, value) {
						toggleHidden(value);
					});
					employerName.val('');
					jobTitle.val('');
					leavingReason.val('');
                    addRequiredFieldValidator(leavingReasonSelector, leavingReasonLabelText);
                    addRequiredFieldValidator(jobTitleSelector, jobTitleLabelText);
                    removeRequiredFieldValidator(gapReasonSelector);
					$(this).prop('value', 1);
					isGapYes.prop('value', 0);
				} else if ($(this).prop('value') == 1) {
					return;
				}
			});

			isCurrentEmployer.on('click', function () {
				if ($(this).prop('checked') == true) {
					removeRequiredFieldValidator(endDateSelector);
					toggleHidden(endDate);
				} else {
					addRequiredFieldValidator(endDateSelector, endDateLabelText);
					toggleHidden(endDate);
				}
			});
		});
	})(window.jQuery);
}
