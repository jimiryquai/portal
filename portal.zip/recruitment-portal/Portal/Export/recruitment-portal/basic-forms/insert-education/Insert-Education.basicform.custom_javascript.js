if (window.jQuery) {
   (function ($) {
      $(document).ready(function () {
         if (typeof (Page_Validators) == 'undefined') return;
         // Create new validator
         var newValidator = document.createElement('span');
         newValidator.style.display = "none";
         newValidator.id = "startdateValidator";
         newValidator.controltovalidate = "pfc_startdate";
         newValidator.validationGroup = ""; // Set this if you have set ValidationGroup on the form
         newValidator.initialvalue = "";
         newValidator.evaluationfunction = function () {
            var startDate = new Date($('#pfc_startdate').val());
            var endDate = new Date($('#pfc_enddate').val());
            var today = Date.now();
            if (startDate > endDate) {
                newValidator.errormessage = "<a href='#pfc_startdate_label'>Start Date must precede End Date.</a>";
                return false;
            } else if (startDate > today) {
                newValidator.errormessage = "<a href='#pfc_startdate_label'>Start Date cannot be in the future.</a>";
                return false; 
             } else {
               return true;
            }
         };

         // Add the new validator to the page validators array:
         Page_Validators.push(newValidator);

         // Wire-up the click event handler of the validation summary link
         $("a[href='#pfc_startdate_label']").on('click', function () {
						scrollToAndFocus('pfc_startdate_label', 'pfc_startdate');
					});
      });
   }(window.jQuery));
}