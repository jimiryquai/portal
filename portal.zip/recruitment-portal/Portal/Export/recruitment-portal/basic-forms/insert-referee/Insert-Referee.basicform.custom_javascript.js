if (window.jQuery) {
	(function ($) {
		$(document).ready(function () {
            var refereeTypeControl = $('#pfc_refereetype');
			var jobTitleControl = $('#jobtitle');
            var jobTitleLabelText = $('#jobtitle_label').text();
            var jobTitleSelector = 'jobtitle';
            jobTitleControl.parent().parent().parent().hide();

			function addRequiredFieldValidator(control, label) {
				if (typeof Page_Validators == 'undefined') return;
				$(`#${control}_label`).parent().addClass('required');
				var validator = document.createElement('span');
				validator.style.display = 'none';
				validator.id = `RequiredFieldValidator${control}`;
				validator.controltovalidate = `${control}`;
				validator.errormessage = "<a href='#" + control + "_label'>" + label + ' is a mandatory field.</a>';
				validator.display = 'Dynamic';
				validator.validationGroup = ''; // Set this if you have set ValidationGroup on the form
				validator.initialvalue = '';
				validator.evaluationfunction = function () {
					var value = $(`#${control}`).val();
					if (value == null || value == '') {
						return false;
					} else {
						return true;
					}
				};
                // Add the new validator to the page validators array:
                Page_Validators.push(validator);

                // Wire-up the click event handler of the validation summary link
                $(`a[href='#${control}_label']`).on('click', function () {
                    scrollToAndFocus(`${control}_label`, `${control}`);
                });
			}

			function removeRequiredFieldValidator(control) {
				$.each(Page_Validators, function (index, validator) {
					if (validator.id == `RequiredFieldValidator${control}`) {
						Page_Validators.splice(index, 1);
						return false;
					}
				});
				$(`#${control}_label`).parent().removeClass('required');
			}

            function findExistingValidator(control) {
				var id;
				$.each(Page_Validators, function (index, validator) {
					if (validator.id == `RequiredFieldValidator${control}`) {
						id = validator.id;
					}
				});
				return id;
			}

            $(refereeTypeControl).change(function () {
                if ($(this).val() == 229330000 || $(this).val() == 229330001) {
                    jobTitleControl.parent().parent().parent().show();
                    var existingId = findExistingValidator(jobTitleSelector);
                    console.log(existingId);
                        if (existingId != undefined) {
                            return false;
                        } else {
                            addRequiredFieldValidator(jobTitleSelector, jobTitleLabelText);
                        }
				} else {
                    jobTitleControl.parent().parent().parent().hide();
                    removeRequiredFieldValidator(jobTitleSelector);
				}
			});
		});
	})(window.jQuery);
}
