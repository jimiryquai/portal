param (
    [Parameter(Mandatory=$True)][string]$envUrlPrefix,
    [Parameter(Mandatory=$True)][string]$adminUser,
    [Parameter(Mandatory=$True)][string]$adminPass
)
Write-Output "Installing dependent modules..."
Install-Module -Name Microsoft.PowerApps.Administration.PowerShell -Force

$securePass = ConvertTo-SecureString -String $adminPass -AsPlainText -Force
$login = Add-PowerAppsAccount -Endpoint "prod" -Username $adminUser -Password $securePass

$environment = Get-AdminPowerAppEnvironment *$envUrlPrefix*
$envGuid = $environment.EnvironmentName.ToString()

#first pass for child WF and standalone 
$flows = Get-AdminFlow -EnvironmentName $envGuid
Write-Output "First Pass to activate flows"
foreach ($flow in $flows)
{
    if($flow.Enabled -eq $false)
    {
        $name = $flow.DisplayName
        Write-Output "Attempting to activate $name"     
        Enable-AdminFlow -EnvironmentName $envGuid -FlowName $flow.FlowName
    }
}

#loop again for dependent flows
$flows = Get-AdminFlow -EnvironmentName $envGuid
Write-Output "Second pass to activate flows that had dependencies"
foreach ($flow in $flows)
{
    if($flow.Enabled -eq $false)
    {
        $namePass2 = $flow.DisplayName
        Write-Output "Attempting to activate $namePass2"     
        Enable-AdminFlow -EnvironmentName $envGuid -FlowName $flow.FlowName
    }
}

#loop for final check and warning if manual internvention needed
$flows = Get-AdminFlow -EnvironmentName $envGuid
Write-Output "Checking for flows that are not enabled at the end of processing"

foreach ($flow in $flows)
{
    if($flow.Enabled -eq $false)
    {
        $name = $flow.DisplayName
        Write-Output "##vso[task.logissue type=warning]The flow '$name' requires manual intervention. If it is the first time used in the environment then you will need to create a connection for the associated connection reference."
    }
}
