// A namespace defined for the code
var ApBpf = window.ApBpf || {};
(function () {
	'use strict';
	// passed to setActiveProcess

	var callBackFunction = function (result) {
		if (result === 'success') {
		} else {
		}
	};

	var getActiveProcessID = function (executionContext) {
		var formContext = executionContext.getFormContext();
		var activeProcessID = null;
		if (formContext.data.process.getActiveProcess().getId() !== null) {
			activeProcessID = formContext.data.process.getActiveProcess().getId().toUpperCase();
		}
		return activeProcessID;
	};

	var getActiveStageID = function (executionContext) {
		var formContext = executionContext.getFormContext();
		var activeStageID = null;
		if (formContext.data.process.getActiveStage().getId() !== null) {
			activeStageID = formContext.data.process.getActiveStage().getId().toUpperCase();
		}
		return activeStageID;
	};

	var stageOnChange = function (executionContext) {
		var formContext = executionContext.getFormContext();
		var callOutcomeText = formContext.getAttribute('pfc_courtesycalloutcome').getText();
		var followUpOutcomeText = formContext.getAttribute('pfc_followupoutcome').getText();
		var acceptedText = 'Offer Accepted';
		var activeProcessID = getActiveProcessID(executionContext);
		var appToOfferProcessID = '042D4E41-6656-4D46-A3BC-B1DD146FA5DA';
		var acceptedProcessID = 'A4E346A0-2D6C-EB11-A812-000D3A870EBD';
		var direction = executionContext.getEventArgs().getDirection();

		if (direction === 'Next') {
			// logic that executes on Applicant to Courtesy Call BPF
			if (activeProcessID === appToOfferProcessID) {
				var courtesyCallStageID = '35068192-EFD1-40F1-93C6-69CF481B50DF';
				var followUpStageID = '117D20F4-844A-4176-85B7-F2B8E12D03D9';
				var activeStageID = getActiveStageID(executionContext);

				if (activeStageID === courtesyCallStageID && callOutcomeText === acceptedText) {
					executionContext.getEventArgs().preventDefault();
					formContext.data.process.setActiveProcess(acceptedProcessID, callBackFunction);
				} else if (activeStageID === followUpStageID && followUpOutcomeText === acceptedText) {
					executionContext.getEventArgs().preventDefault();
					formContext.data.process.setActiveProcess(acceptedProcessID, callBackFunction);
				}
			}
		}
	};

	var hideJsSection = function (executionContext) {
		var formContext = executionContext.getFormContext();
		var tabObj = formContext.ui.tabs.get('general_tab');
		var sectionObj = tabObj.sections.get('general_tab_javascript_section');
		sectionObj.setVisible(false);
	};

	// Code to run in the form OnLoad event
	this.formOnLoad = function (executionContext) {
		var formContext = executionContext.getFormContext();
		formContext.data.process.addOnPreStageChange(stageOnChange);
		hideJsSection(executionContext);
	};

	// Code to run in the attribute OnChange event
	// Auto save form so that instant flows on bpf don't fail
	this.attributeOnChange = function (executionContext) {
		var formContext = executionContext.getFormContext();
		var saveForm = formContext.data.save(1);

		if (!null) {
			saveForm;
		}
	};
}.call(ApBpf));
